# go-unzip
Concurrently unzips files in the specified folder
